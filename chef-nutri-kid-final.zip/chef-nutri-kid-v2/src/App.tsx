import React, { useState, useRef } from 'react';
import { Sparkles, Utensils, BookOpen, UserCheck, ShieldAlert, Award, ArrowLeft, Search, HelpCircle, Activity, ChevronRight, Upload, PlayCircle, Globe, Calendar as CalendarIcon, Leaf, Users, Download, BookmarkPlus, Bookmark, Book, Trash2, Lock, Crown, X } from 'lucide-react';
import IngredientSelector from './components/IngredientSelector';
import HarvardPlate from './components/HarvardPlate';
import WeeklyPlanner from './components/WeeklyPlanner';
import ProfileManager from './components/ProfileManager';
import { Recipe, DietaryPreference, ChildProfile, HealthReport } from './types';
import { downloadAsPDF } from './utils';
import { freemium } from './freemium';

export default function App() {
  const [activeTab, setActiveTab] = useState<'pantry' | 'weekly' | 'box'>('pantry');
  // ── Freemium gate state ──
  const [isPremium, setIsPremium] = useState<boolean>(freemium.isPremium());
  const [hasUsedFree, setHasUsedFree] = useState<boolean>(freemium.hasUsedFree());
  const [showPaywall, setShowPaywall] = useState<boolean>(false);
  const [paywallReason, setPaywallReason] = useState<'generate' | 'profile' | 'report' | 'weekly' | 'save'>('generate');
  const [unlockCode, setUnlockCode] = useState<string>('');
  const [unlockError, setUnlockError] = useState<string>('');

  const triggerPaywall = (reason: typeof paywallReason) => {
    setPaywallReason(reason);
    setShowPaywall(true);
  };

  const handleUnlock = () => {
    setUnlockError('');
    if (freemium.unlock(unlockCode)) {
      setIsPremium(true);
      setShowPaywall(false);
      setUnlockCode('');
    } else {
      setUnlockError('Invalid code. Please check your activation code and try again.');
    }
  };

  const [selectedIngredients, setSelectedIngredients] = useState<string[]>(['Broccoli', 'Carrots', 'Brown Rice', 'Chicken Breast', 'Eggs', 'Olive Oil', 'Fresh Water']);
  const [language, setLanguage] = useState<string>('English');
  const [diet, setDiet] = useState<DietaryPreference>('Any / No Restriction');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [recipeOptions, setRecipeOptions] = useState<Recipe[] | null>(null);
  const [healthReport, setHealthReport] = useState<HealthReport | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [completedTasks, setCompletedTasks] = useState<string[]>([]);
  const [moveChallengeDone, setMoveChallengeDone] = useState<boolean>(false);
  const [showMoveConfetti, setShowMoveConfetti] = useState<boolean>(false);
  const [uploadedPhotos, setUploadedPhotos] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Recipe Box State
  const [savedRecipes, setSavedRecipes] = useState<Recipe[]>(() => {
    try {
      const stored = localStorage.getItem('nutripeds_recipe_box');
      return stored ? JSON.parse(stored) : [];
    } catch(e) { return []; }
  });

  React.useEffect(() => {
    localStorage.setItem('nutripeds_recipe_box', JSON.stringify(savedRecipes));
  }, [savedRecipes]);

  // Profile Management State
  const [profiles, setProfiles] = useState<ChildProfile[]>([]);
  const [activeProfileId, setActiveProfileId] = useState<string | null>(null);
  const [showProfileModal, setShowProfileModal] = useState<boolean>(false);

  const activeProfile = profiles.find(p => p.id === activeProfileId);

  // Playful cooking state tips to rotate through during generation
  const [loadingTipIndex, setLoadingTipIndex] = useState(0);
  const loadingTips = [
    "Washing our fresh vegetables to create superhero shields... 🥬🧼",
    "Gently measuring out the steady-energy whole grains... 🌾📏",
    "Prepping the muscle-builder proteins with kid-glove care... 🍗🔬",
    "Stir-frying up some magic with cold-pressed olive oil... 🫗✨",
    "Pouring custom hydration cups to keep our brains sparkling... 💧🧠",
    "Chef Nutri-Kid is polishing the golden dining spoons... 🥄⭐"
  ];

  // Dynamic interval to change tips during loading
  React.useEffect(() => {
    let timer: any;
    if (isLoading) {
      timer = setInterval(() => {
        setLoadingTipIndex((prev) => (prev + 1) % loadingTips.length);
      }, 2500);
    }
    return () => clearInterval(timer);
  }, [isLoading]);

  const handleGenerateRecipe = async () => {
    // Freemium gate — block if used free trial and not premium
    if (!isPremium && hasUsedFree) {
      triggerPaywall('generate');
      return;
    }
    setIsLoading(true);
    setError(null);
    setCompletedTasks([]);
    setMoveChallengeDone(false);
    setShowMoveConfetti(false);
    setUploadedPhotos([]);
    setHealthReport(null);

    try {
      const ingredientString = selectedIngredients.join(', ');
      
      const requestBody: any = { ingredients: ingredientString, language, diet: activeProfile ? activeProfile.foodCategories : diet };
      if (activeProfile) {
         requestBody.childProfile = activeProfile;
      }

      const response = await fetch('/api/recipe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('API server not found! Please ensure your backend functions are deployed and GEMINI_API_KEY is configured in your hosting environment.');
        }
        let errMessage = 'Our baking ovens got a bit too hot! Let\'s try mixing ingredients again.';
        try {
            const errData = await response.json();
            if (errData.error) errMessage = errData.error;
        } catch (e) {}
        throw new Error(errMessage);
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      if (data.recipes && Array.isArray(data.recipes)) {
        setRecipeOptions(data.recipes);
        // Mark free trial as used after first successful generation
        if (!isPremium) {
          freemium.markUsed();
          setHasUsedFree(true);
        }
      } else {
        throw new Error("Invalid response format received from the server.");
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Something went wrong in Chef Nutri-Kid\'s kitchen. Please make sure your server is online.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateReport = async (profile: ChildProfile) => {
    if (!isPremium) { triggerPaywall('report'); return; }
    setIsLoading(true);
    setError(null);
    setRecipe(null);
    setHealthReport(null);
    setShowProfileModal(false);

    try {
      const response = await fetch('/api/health-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ childProfile: profile, language })
      });

      if (!response.ok) {
        let errMessage = 'Failed to generate report.';
        try { const errData = await response.json(); if(errData.error) errMessage = errData.error; } catch(e) {}
        throw new Error(errMessage);
      }

      const data = await response.json();
      setHealthReport(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to generate the creative health report.');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleTask = (task: string) => {
    if (completedTasks.includes(task)) {
      setCompletedTasks(completedTasks.filter(t => t !== task));
    } else {
      setCompletedTasks([...completedTasks, task]);
    }
  };

  const handleCompleteMoveChallenge = () => {
    setMoveChallengeDone(true);
    setShowMoveConfetti(true);
    setTimeout(() => {
      setShowMoveConfetti(false);
    }, 4000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result && typeof e.target.result === 'string') {
          setUploadedPhotos(prev => [...prev, e.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  return (
    <div className="min-h-screen bg-[#FFFDF0] font-sans pb-16 transition-all duration-300">
      {/* Visual Accent top ribbon */}
      <div className="h-3 bg-gradient-to-r from-[#FF6B6B] via-[#FFD93D] to-[#4ECDC4]"></div>

      {showPaywall && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-[60] backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-7 shadow-2xl border-4 border-[#FFD93D] w-full max-w-md">
            <div className="flex justify-between items-start mb-4">
              <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center text-3xl mb-1">🔒</div>
              <button onClick={() => { setShowPaywall(false); setUnlockError(''); setUnlockCode(''); }} className="p-2 hover:bg-slate-100 rounded-full"><X className="w-5 h-5 text-slate-400" /></button>
            </div>
            <h2 className="text-2xl font-black text-slate-800 mb-1">
              {paywallReason === 'generate' ? '🍳 Free Trial Used!' :
               paywallReason === 'profile' ? '👤 Child Profiles — Premium' :
               paywallReason === 'report' ? '📊 Health Reports — Premium' :
               paywallReason === 'weekly' ? '📅 Weekly Planner — Premium' :
               '🔖 Recipe Box — Premium'}
            </h2>
            <p className="text-slate-500 text-sm mb-5 leading-relaxed">
              {paywallReason === 'generate'
                ? 'You\'ve used your 1 free recipe generation. Upgrade to a plan to generate unlimited recipes, save favourites, and access all premium features!'
                : 'This feature is available to paid plan members. Upgrade to unlock child profiles, health reports, weekly planners, and unlimited recipe generation!'}
            </p>

            {/* Plan quick links */}
            <div className="space-y-2 mb-5">
              {[
                { name: '🌱 Starter', price: '₹299/week', desc: 'Unlimited recipes + WhatsApp plan' },
                { name: '👨‍👩‍👧 Family', price: '₹999/month', desc: 'Profiles + weekly planner + 3 children' },
                { name: '⭐ Premium', price: '₹2,499/month', desc: 'All features + video consultations' },
              ].map(plan => (
                <div key={plan.name} className="flex items-center justify-between bg-amber-50 border border-amber-200 rounded-2xl px-4 py-3">
                  <div>
                    <div className="font-bold text-sm text-slate-800">{plan.name} — <span className="text-[#FF6B6B]">{plan.price}</span></div>
                    <div className="text-xs text-slate-500">{plan.desc}</div>
                  </div>
                  <a href="/payment.html" target="_blank" rel="noreferrer">
                    <button className="text-xs bg-[#FF6B6B] text-white px-3 py-1.5 rounded-xl font-bold hover:bg-red-500 transition-colors">
                      Get →
                    </button>
                  </a>
                </div>
              ))}
            </div>

            <div className="border-t border-slate-100 pt-4">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Already have an activation code?</p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={unlockCode}
                  onChange={e => { setUnlockCode(e.target.value); setUnlockError(''); }}
                  onKeyDown={e => e.key === 'Enter' && handleUnlock()}
                  placeholder="Enter code e.g. NUTRI-STARTER"
                  className="flex-1 p-3 border-2 border-slate-200 rounded-xl text-sm font-bold focus:border-[#FF6B6B] outline-none"
                />
                <button onClick={handleUnlock} className="px-4 py-3 bg-[#4ECDC4] text-white rounded-xl font-bold text-sm hover:bg-teal-500 transition-colors">
                  Unlock
                </button>
              </div>
              {unlockError && <p className="text-xs text-red-500 font-bold mt-2">{unlockError}</p>}
              <p className="text-xs text-slate-400 mt-2">You'll receive an activation code on WhatsApp after payment confirmation.</p>
            </div>
          </div>
        </div>
      )}

      {showProfileModal && (
        <ProfileManager 
          profiles={profiles} 
          setProfiles={setProfiles} 
          activeProfileId={activeProfileId} 
          setActiveProfileId={setActiveProfileId} 
          onClose={() => setShowProfileModal(false)}
          onGenerateReport={handleGenerateReport}
          isPremium={isPremium}
        />
      )}

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">

        {/* Global Header Section */}
        <header className="print:hidden flex flex-col sm:flex-row items-center justify-between bg-white rounded-3xl p-5 md:p-6 shadow-sm border-2 border-[#FFD966] mb-6 gap-4 relative">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-[#FF6B6B] rounded-2xl flex items-center justify-center text-4xl shadow-md animate-chef-bounce">
              👨‍🍳
            </div>
            <div>
              <h1 id="app-title" className="text-2xl sm:text-3xl font-black text-[#4A4A4A] tracking-tight">
                CHEF NUTRI-KID
              </h1>
              <p className="text-xs sm:text-sm font-bold text-[#FF6B6B] flex items-center gap-1.5">
                Powered by NutriPeds AI <span className="animate-pulse">🌟</span>
              </p>
            </div>
          </div>

          {/* Profile & Controls */}
          <div className="flex flex-col items-center sm:items-end gap-3 text-center sm:text-right">
            <div className="flex items-center gap-2">
              <button 
                onClick={() => isPremium ? setShowProfileModal(true) : triggerPaywall('profile')}
                className={`px-4 py-2 rounded-2xl text-white font-black text-xs shadow-sm uppercase tracking-wider flex items-center gap-2 transition-colors border-2 ${isPremium ? 'bg-[#4ECDC4] hover:bg-teal-500 border-teal-600' : 'bg-slate-400 hover:bg-slate-500 border-slate-500'}`}
              >
                {isPremium ? <Users className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                {isPremium
                  ? (activeProfile ? `Profile: ${activeProfile.name}` : 'NutriPeds Profiles')
                  : 'Profiles — Premium 🔒'}
              </button>
            </div>
            
            <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-2xl border border-slate-200 shadow-sm">
              <Leaf className="w-4 h-4 text-emerald-500" />
              {activeProfile ? (
                 <span className="bg-transparent text-sm font-bold text-emerald-700 outline-hidden tracking-wide">{activeProfile.foodCategories}</span>
              ) : (
                <select
                  value={diet}
                  onChange={(e) => setDiet(e.target.value as DietaryPreference)}
                  className="bg-transparent text-sm font-bold text-emerald-700 outline-hidden cursor-pointer"
                >
                  {['Any / No Restriction', 'Vegetarian', 'Non-Vegetarian', 'Vegan', 'Eggetarian', 'Jain'].map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              )}
            </div>
            
            <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-2xl border border-slate-200 shadow-sm">
              <Globe className="w-4 h-4 text-slate-500" />
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="bg-transparent text-sm font-bold text-slate-600 outline-hidden cursor-pointer"
              >
                {["English", "Español", "Français", "Deutsch", "Italiano", "Português", "Hindi"].map(lang => (
                  <option key={lang} value={lang}>{lang}</option>
                ))}
              </select>
            </div>
          </div>
        </header>

        {/* Navigation Tabs */}
        {!recipe && !healthReport && (
          <div className="print:hidden flex justify-center mb-8">
            <div className="inline-flex bg-white p-1 rounded-2xl border-2 border-slate-200 shadow-sm">
              <button
                onClick={() => setActiveTab('pantry')}
                className={`px-6 py-3 rounded-xl font-bold text-sm sm:text-base flex items-center gap-2 transition-all ${
                  activeTab === 'pantry' ? 'bg-[#FF6B6B] text-white shadow-md' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Utensils className="w-5 h-5" /> Pantry Chef
              </button>
              <button
                onClick={() => isPremium ? setActiveTab('weekly') : triggerPaywall('weekly')}
                className={`px-6 py-3 rounded-xl font-bold text-sm sm:text-base flex items-center gap-2 transition-all ${
                  activeTab === 'weekly' ? 'bg-indigo-500 text-white shadow-md' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                {isPremium ? <CalendarIcon className="w-5 h-5" /> : <Lock className="w-4 h-4" />} Weekly Planner
                {!isPremium && <span className="text-[10px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full font-black">PRO</span>}
              </button>
              <button
                onClick={() => isPremium ? setActiveTab('box') : triggerPaywall('save')}
                className={`px-6 py-3 rounded-xl font-bold text-sm sm:text-base flex items-center gap-2 transition-all ${
                  activeTab === 'box' ? 'bg-emerald-500 text-white shadow-md' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                {isPremium ? <Book className="w-5 h-5" /> : <Lock className="w-4 h-4" />} Recipe Box
                {!isPremium && <span className="text-[10px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full font-black">PRO</span>}
              </button>
            </div>
          </div>
        )}

        {/* Error Notification Banner */}
        {error && (
          <div className="mb-6 p-4 bg-rose-50 border-2 border-rose-300 rounded-2xl flex items-start gap-3 text-rose-800 shadow-sm">
            <ShieldAlert className="w-6 h-6 text-rose-500 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-sm">A Little Kitchen Spill Occurred!</h4>
              <p className="text-xs text-rose-700 mt-1">{error}</p>
            </div>
          </div>
        )}

        {/* Main Interface Arena */}
        {healthReport ? (
           <div id="health-report-pdf-container" className="space-y-6 bg-white p-4 sm:p-6 rounded-3xl">
              <div className="flex justify-between items-center bg-indigo-50 rounded-2xl p-4 border border-indigo-200">
                <h2 className="text-xl font-black text-indigo-900 flex items-center gap-2">
                  <Activity className="w-6 h-6 text-indigo-500" /> NutriPeds Clinical Report: {healthReport.childName}
                </h2>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => downloadAsPDF('health-report-pdf-container', 'health-report.pdf')} 
                    className="print:hidden px-4 py-2 bg-indigo-100 hover:bg-indigo-200 text-indigo-700 font-bold text-xs sm:text-sm rounded-xl flex items-center gap-2 transition-colors border border-indigo-200"
                  >
                    <Download className="w-4 h-4" /> Download PDF
                  </button>
                  <button
                    type="button"
                    onClick={() => setHealthReport(null)}
                    className="print:hidden px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs sm:text-sm border border-slate-350 shadow-xs flex items-center gap-2 transition-all"
                  >
                    <ArrowLeft className="w-4 h-4" /> Go back
                  </button>
                </div>
              </div>

              {healthReport.medicalDisclaimer && (
                <div className="bg-yellow-50 p-4 border-l-4 border-yellow-400 rounded-r-xl">
                  <p className="text-xs font-bold text-yellow-800 uppercase tracking-widest mb-1">MANDATORY MEDICAL DISCLAIMER</p>
                  <p className="text-xs text-yellow-900 font-medium">{healthReport.medicalDisclaimer}</p>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-3xl border-2 border-slate-200 shadow-sm">
                  <h3 className="text-slate-800 font-black text-lg mb-3">Health Summary</h3>
                  <p className="text-slate-600 text-sm font-medium leading-relaxed">{healthReport.healthSummary}</p>
                </div>
                
                <div className="bg-indigo-50 p-6 rounded-3xl border-2 border-indigo-200 shadow-sm relative overflow-hidden">
                  <Activity className="w-24 h-24 text-indigo-200 absolute -right-4 -bottom-4 opacity-30" />
                  <h3 className="text-indigo-900 font-black text-lg mb-3">Growth Chart Analysis</h3>
                  <p className="text-indigo-800 text-sm font-medium leading-relaxed">{healthReport.growthChartAnalysis}</p>
                </div>

                <div className="bg-emerald-50 p-6 rounded-3xl border-2 border-emerald-200 shadow-sm md:col-span-2">
                  <h3 className="text-emerald-900 font-black text-lg mb-4 flex items-center gap-2">
                    <Utensils className="w-5 h-5 text-emerald-500" /> The "Proactive Plate" Strategy
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {healthReport.proactivePlateStrategy.map((strategy, i) => (
                      <div key={i} className="bg-white p-4 rounded-xl border border-emerald-100 shadow-sm">
                        <div className="bg-emerald-100 text-emerald-800 w-8 h-8 flex items-center justify-center rounded-full font-black mb-3">{i + 1}</div>
                        <p className="text-xs font-bold text-slate-700 leading-snug">{strategy}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {healthReport.allergySafetyShield && (
                  <div className="bg-rose-50 p-6 rounded-3xl border-2 border-rose-300 shadow-sm md:col-span-2">
                    <h3 className="text-rose-900 font-black text-lg mb-3 flex items-center gap-2">
                      <ShieldAlert className="w-5 h-5 text-rose-500" /> Allergy Safety Shield
                    </h3>
                    <p className="text-rose-800 text-sm font-bold bg-white p-4 rounded-xl border border-rose-200 shadow-xs">
                      {healthReport.allergySafetyShield}
                    </p>
                  </div>
                )}
                
                <div className="bg-[#FFFBEB] p-6 rounded-3xl border-2 border-[#FFD93D] shadow-sm md:col-span-2">
                  <h3 className="text-[#A35D36] font-black text-lg mb-3">Milestone & Energy Tracker</h3>
                  <p className="text-[#854d0e] text-sm font-bold leading-relaxed">{healthReport.milestoneTracker}</p>
                </div>
              </div>
           </div>
        ) : !recipe ? (
          /* View A: Selector Views */
          <div className="space-y-6">
            {activeTab === 'weekly' ? (
              <WeeklyPlanner language={language} diet={activeProfile ? activeProfile.foodCategories : diet} childProfile={activeProfile} />
            ) : activeTab === 'box' ? (
              <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border-2 border-emerald-100 min-h-[400px]">
                 <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2 mb-6 uppercase">
                   <Book className="w-6 h-6 text-emerald-500" /> Saved NutriPeds Recipes
                 </h2>
                 {savedRecipes.length === 0 ? (
                   <div className="text-center p-8 bg-emerald-50 rounded-2xl border-2 border-dashed border-emerald-200 flex flex-col items-center justify-center">
                     <Book className="w-12 h-12 text-emerald-300 mb-3" />
                     <p className="text-emerald-800 font-bold">Your Recipe Box is empty!</p>
                     <p className="text-emerald-600 text-sm mt-1">Generate recipes in the Pantry Chef and save your favorites here.</p>
                     <button onClick={() => setActiveTab('pantry')} className="mt-4 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-sm transition-colors text-sm">
                       Go back to Pantry Chef
                     </button>
                   </div>
                 ) : (
                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                     {savedRecipes.map((r, i) => (
                       <div key={i} className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-5 shadow-sm hover:shadow-md hover:border-emerald-300 transition-all cursor-pointer group flex flex-col justify-between h-full" onClick={() => { setRecipe(r); setActiveTab('pantry'); }}>
                         <div>
                           <p className="text-[10px] uppercase font-extrabold tracking-widest text-[#A35D36] mb-1">
                             ✨ {r.dietIndicator}
                           </p>
                           <h3 className="text-lg font-black text-[#7D4427] leading-tight mb-3 line-clamp-2">{r.mealName}</h3>
                           <div className="flex flex-wrap gap-1 mb-3">
                              <span className="text-[10px] font-bold bg-sky-100 text-sky-800 px-2 py-0.5 rounded-full">{r.nutrition.calories} kcal</span>
                              <span className="text-[10px] font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full">{r.nutrition.protein} prot</span>
                           </div>
                         </div>
                         <div className="flex justify-end mt-4 pt-3 border-t border-slate-200">
                           <button 
                             onClick={(e) => { e.stopPropagation(); setSavedRecipes(savedRecipes.filter((_, index) => index !== i)); }}
                             className="text-xs text-rose-500 hover:text-rose-700 font-bold p-1 group-hover:block transition-colors"
                           >
                              Remove
                           </button>
                         </div>
                       </div>
                     ))}
                   </div>
                 )}
              </div>
            ) : isLoading ? (
              /* Loading State Screen with rotating tips */
              <div className="bg-white rounded-3xl p-12 text-center border-4 border-[#FF6B6B] shadow-xl max-w-2xl mx-auto my-12 animate-pulse">
                <div className="text-6xl mb-6">🌋</div>
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-[#4ECDC4] mb-4"></div>
                <h3 className="text-2xl font-black text-slate-705">Mixing in Chef Nutri-Kid's Blender...</h3>
                
                <div className="mt-6 p-4 bg-amber-50 rounded-2xl border border-amber-200">
                  <p className="text-[#A35D36] font-bold text-md italic animate-bounce">
                    "{loadingTips[loadingTipIndex]}"
                  </p>
                </div>
                
                <p className="text-slate-400 text-xs mt-6">
                  Applying clinical nutrient ratios using Gemini AI for kid goodness...
                </p>
              </div>
            ) : recipeOptions ? (
              /* Display Recipe Options */
              <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border-2 border-indigo-100 min-h-[400px]">
                 <div className="flex justify-between items-center mb-6">
                   <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2 uppercase">
                     <Sparkles className="w-6 h-6 text-amber-500" /> Chef Nutri-Kid's Options
                   </h2>
                   <button
                     onClick={() => setRecipeOptions(null)}
                     className="px-4 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 font-bold text-xs sm:text-sm border border-slate-200 transition-colors"
                   >
                     Back to Pantry
                   </button>
                 </div>
                 <p className="text-slate-600 mb-6 font-medium">Select your favorite recipe option below to see full details!</p>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   {recipeOptions.map((opt, i) => (
                     <div key={i} className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-indigo-300 transition-all cursor-pointer group flex flex-col justify-between" onClick={() => { setRecipe(opt); setRecipeOptions(null); }}>
                       <div>
                         <p className="text-xs uppercase font-extrabold tracking-widest text-[#A35D36] mb-2">
                           ✨ Option {i + 1} | {opt.dietIndicator}
                         </p>
                         <h3 className="text-xl font-black text-indigo-900 leading-tight mb-4">{opt.mealName}</h3>
                         {opt.nutritionalFocus && (
                           <p className="text-sm font-medium text-slate-600 mb-4 bg-indigo-50 p-3 rounded-xl line-clamp-3">
                             {opt.nutritionalFocus}
                           </p>
                         )}
                         <div className="flex flex-wrap gap-2 mb-4">
                            <span className="text-xs font-bold bg-sky-100 text-sky-800 px-3 py-1 rounded-full">{opt.nutrition.calories} kcal</span>
                            <span className="text-xs font-bold bg-rose-100 text-rose-800 px-3 py-1 rounded-full">{opt.nutrition.protein} prot</span>
                         </div>
                       </div>
                       <button className="mt-4 w-full py-2 bg-indigo-500 hover:bg-indigo-600 text-white font-bold rounded-xl shadow-sm transition-colors text-sm">
                         View Full Recipe
                       </button>
                     </div>
                   ))}
                 </div>
              </div>
            ) : (
              /* Ready to pick ingredients */
              <div className="space-y-4">
                {/* Free trial banner */}
                {!isPremium && (
                  <div className={`flex items-center justify-between gap-3 px-5 py-3 rounded-2xl border-2 ${hasUsedFree ? 'bg-rose-50 border-rose-300' : 'bg-amber-50 border-[#FFD93D]'}`}>
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{hasUsedFree ? '🔒' : '🎁'}</span>
                      <div>
                        <p className="font-black text-sm text-slate-800">
                          {hasUsedFree ? 'Free trial used!' : '1 Free Recipe Generation Available'}
                        </p>
                        <p className="text-xs text-slate-500">
                          {hasUsedFree
                            ? 'Upgrade to a plan to generate unlimited recipes & unlock all features.'
                            : 'Try Chef Nutri-Kid once for free. Upgrade to unlock unlimited generations + all features!'}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => triggerPaywall('generate')}
                      className="shrink-0 px-4 py-2 bg-[#FF6B6B] text-white text-xs font-black rounded-xl hover:bg-red-500 transition-colors"
                    >
                      {hasUsedFree ? 'Upgrade →' : 'See Plans'}
                    </button>
                  </div>
                )}
                <IngredientSelector
                  selectedItems={selectedIngredients}
                  onChangeSelected={setSelectedIngredients}
                  onGenerate={handleGenerateRecipe}
                  isLoading={isLoading}
                  diet={activeProfile ? activeProfile.foodCategories : diet}
                />
              </div>
            )}
          </div>
        ) : (
          /* View B: Active Recipe Plate & Steps */
          <div className="space-y-6">
            
            {/* Header recipe alert with return button */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#FFE8D6] rounded-2xl p-4 border-2 border-[#FFB280]">
              <div>
                <p className="text-xs uppercase font-extrabold tracking-widest text-[#A35D36]">
                  ✨ Fresh Out of the Kitchen {recipe.dietIndicator && <span className="bg-white/50 px-2 py-0.5 rounded-full ml-2 inline-block shadow-xs border border-white/60">{recipe.dietIndicator}</span>}
                </p>
                <h2 id="recipe-meal-title" className="text-2xl font-black text-[#7D4427] leading-tight">
                  {recipe.mealName}
                </h2>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (!isPremium) { triggerPaywall('save'); return; }
                    const alreadySaved = savedRecipes.some(r => r.mealName === recipe.mealName);
                    if (alreadySaved) {
                       setSavedRecipes(savedRecipes.filter(r => r.mealName !== recipe.mealName));
                    } else {
                       setSavedRecipes([...savedRecipes, recipe]);
                    }
                  }}
                  className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm border shadow-xs flex items-center gap-2 transition-all ${
                    !isPremium
                      ? 'bg-slate-100 border-slate-200 text-slate-500'
                      : savedRecipes.some(r => r.mealName === recipe.mealName)
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-800 hover:bg-emerald-200'
                        : 'bg-white hover:bg-amber-50 text-emerald-700 border-emerald-200'
                  }`}
                >
                  {!isPremium
                    ? <><Lock className="w-4 h-4" /> Save Recipe 🔒</>
                    : savedRecipes.some(r => r.mealName === recipe.mealName)
                      ? <><Bookmark className="w-4 h-4 fill-current" /> Saved to Box</>
                      : <><BookmarkPlus className="w-4 h-4" /> Save Recipe</>
                  }
                </button>
                <button
                  id="btn-return-fridge"
                  type="button"
                  onClick={() => setRecipe(null)}
                  className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs sm:text-sm border border-slate-350 shadow-xs flex items-center gap-2 transition-all"
                >
                  <ArrowLeft className="w-4 h-4" /> Go back
                </button>
              </div>
            </div>

            {recipe.medicalDisclaimer && (
              <div className="bg-yellow-50 p-4 border-l-4 border-yellow-400 rounded-r-xl shadow-xs">
                <p className="text-xs font-bold text-yellow-800 uppercase tracking-widest mb-1">MANDATORY MEDICAL DISCLAIMER</p>
                <p className="text-xs text-yellow-900 font-medium">{recipe.medicalDisclaimer}</p>
              </div>
            )}

            {/* Main Interactive 12-Column Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Side: 5-Col Harvard Plate Visualization */}
              <div className="lg:col-span-5 flex flex-col space-y-6">
                <HarvardPlate recipe={recipe} />

                {/* Nutripeds specific facts */}
                {recipe.nutritionalFocus && (
                  <div className="bg-[#F1F8E9] p-5 rounded-3xl border-2 border-[#95CD41] shadow-sm relative overflow-hidden">
                    <span className="absolute top-2 right-2 text-3xl opacity-15">🔬</span>
                    <h5 className="text-xs font-black text-[#33691E] uppercase tracking-wider mb-2 flex items-center gap-2">
                      <Award className="w-4 h-4 text-[#33691E]" /> NUTRIPEDS COCHING FACT
                    </h5>
                    <p className="text-xs font-bold text-[#558B2F]">
                      {recipe.nutritionalFocus}
                    </p>
                  </div>
                )}
                
                {recipe.allergyCheck && (
                  <div className="bg-rose-50 p-5 rounded-3xl border-2 border-rose-300 shadow-sm relative overflow-hidden">
                    <span className="absolute top-2 right-2 text-3xl opacity-15">🛡️</span>
                    <h5 className="text-xs font-black text-rose-700 uppercase tracking-wider mb-2 flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-rose-500" /> ALLERGY SAFETY SHIELD
                    </h5>
                    <p className="text-xs font-bold text-rose-800">
                      {recipe.allergyCheck}
                    </p>
                  </div>
                )}

                {/* Nutrition Breakdown */}
                {recipe.nutrition && (
                   <div className="bg-white p-5 rounded-3xl border-2 border-slate-200 shadow-sm">
                      <h4 className="text-slate-800 font-black text-sm uppercase mb-4 flex items-center gap-2">
                        <Activity className="w-5 h-5 text-sky-500" /> Nutritional Power (Kid's Portion)
                      </h4>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-sky-50 p-3 rounded-2xl flex flex-col items-center justify-center text-center">
                           <span className="text-2xl font-black text-sky-600">{recipe.nutrition.calories}</span>
                           <span className="text-[10px] font-bold text-sky-800 uppercase">Calories 🔥</span>
                        </div>
                        <div className="bg-rose-50 p-3 rounded-2xl flex flex-col items-center justify-center text-center">
                           <span className="text-lg font-black text-rose-600">{recipe.nutrition.protein}</span>
                           <span className="text-[10px] font-bold text-rose-800 uppercase">Protein 💪</span>
                        </div>
                        <div className="bg-amber-50 p-3 rounded-2xl flex flex-col items-center justify-center text-center">
                           <span className="text-lg font-black text-amber-600">{recipe.nutrition.carbs}</span>
                           <span className="text-[10px] font-bold text-amber-800 uppercase">Carbs ⚡</span>
                        </div>
                        <div className="bg-emerald-50 p-3 rounded-2xl flex flex-col items-center justify-center text-center">
                           <span className="text-lg font-black text-emerald-600">{recipe.nutrition.fiber}</span>
                           <span className="text-[10px] font-bold text-emerald-800 uppercase">Fiber 🌿</span>
                        </div>
                        <div className="col-span-2 bg-yellow-50 p-3 rounded-2xl text-center flex items-center justify-center gap-2">
                           <span className="text-xs font-black text-yellow-800">Key Vitamins: 🌟 {recipe.nutrition.keyVitamins}</span>
                        </div>
                      </div>
                   </div>
                )}
              </div>

              {/* Right Side: 7-Col Instructions, Tasks, Move Challenge */}
              <div className="lg:col-span-7 flex flex-col space-y-6">
                
                {/* Steps Section */}
                <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border-2 border-gray-100 flex-1">
                  <h3 className="text-[#4A4A4A] font-black text-xl mb-6 flex items-center gap-2">
                    <Utensils className="w-6 h-6 text-[#FF6B6B]" /> 👩‍🍳 EASY STEP-BY-STEP RECIPE
                  </h3>

                  <div className="space-y-5">
                    {recipe.instructions.map((step, idx) => (
                      <div key={idx} className="flex space-x-4 items-start">
                        <div className="font-black text-2xl text-[#4ECDC4] opacity-50 select-none mt-0.5">
                          {String(idx + 1).padStart(2, '0')}
                        </div>
                        <p className="text-sm sm:text-base text-slate-700 leading-relaxed font-medium">
                          {step}
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Junior Assistant Tasks Section */}
                  <div className="mt-8 bg-[#E0F7FA] border-2 border-[#4ECDC4] rounded-2xl p-5 md:p-6">
                    <h4 className="text-[#00838F] font-black text-sm uppercase tracking-widest mb-3 flex items-center gap-2">
                      <UserCheck className="w-5 h-5 text-[#00838F]" /> 🧑‍🍳 JUNIOR CHEF SAFE TASKS
                    </h4>
                    <p className="text-xs text-slate-500 mb-4 font-semibold">
                      Hey there kiddo! Tap and check off your kitchen chores to finish this dish safely:
                    </p>

                    <div className="space-y-2.5">
                      {recipe.juniorDuties.map((task, idx) => {
                        const isDone = completedTasks.includes(task);
                        return (
                          <div
                            key={idx}
                            id={`junior-task-box-${idx}`}
                            onClick={() => toggleTask(task)}
                            className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                              isDone
                                ? 'bg-teal-50 border-teal-300 text-teal-800 line-through opacity-85'
                                : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isDone}
                              onChange={() => {}} // toggled via parent div click
                              className="accent-teal-600 h-4 w-4 rounded-md pointer-events-none"
                            />
                            <span className="text-xs sm:text-sm font-bold leading-tight">
                              {task}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    {completedTasks.length === recipe.juniorDuties.length && (
                      <div className="mt-4 p-3 bg-teal-100 rounded-xl text-teal-900 border border-teal-400 text-center animate-bounce text-xs font-extrabold flex items-center justify-center gap-2">
                        🌟 Double High Five! Junior Chef Assistant Complete! 🥳
                      </div>
                    )}
                  </div>
                </div>

                {/* Upload Photos Section */}
                <div className="bg-white rounded-3xl p-6 border-2 border-indigo-100 shadow-sm">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-3">
                    <h4 className="text-indigo-800 font-black text-sm uppercase flex items-center gap-2">
                      <Upload className="w-5 h-5 text-indigo-500" /> Share Your Masterpiece! 📸
                    </h4>
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl transition-colors border border-indigo-200 shadow-sm"
                    >
                      Upload Photo
                    </button>
                    <input 
                      type="file" 
                      accept="image/*" 
                      multiple
                      className="hidden" 
                      ref={fileInputRef}
                      onChange={handleFileUpload}
                    />
                  </div>
                  {uploadedPhotos.length > 0 ? (
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                      {uploadedPhotos.map((photo, i) => (
                        <div key={i} className="aspect-square rounded-2xl overflow-hidden border-2 border-indigo-200 shadow-sm group relative">
                          <img src={photo} alt="Uploaded meal" className="w-full h-full object-cover transition-transform group-hover:scale-110" />
                          <button 
                            onClick={() => setUploadedPhotos(prev => prev.filter((_, index) => index !== i))}
                            className="absolute top-1 right-1 bg-white/80 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                           <Trash2 className="w-3 h-3 text-rose-500" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-indigo-200 rounded-2xl p-6 text-center bg-indigo-50/50">
                       <p className="text-indigo-400 font-medium text-xs sm:text-sm">No photos yet! Upload your plate here when finished so we can celebrate! 🎉</p>
                    </div>
                  )}
                </div>

                {/* Row Grid: Move Challenge & Scientific Fact */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Why this is powerful card */}
                  <div className="bg-[#FFE8D6] p-5 rounded-3xl border-2 border-[#FFB280] flex flex-col justify-between">
                    <div>
                      <h5 className="text-[10px] font-black text-[#A35D36] uppercase tracking-widest mb-2 flex items-center gap-1.5">
                        💡 WHY IT'S A POWER MEAL
                      </h5>
                      <p className="text-xs sm:text-sm font-bold text-[#7D4427] italic leading-relaxed">
                        "{recipe.powerMealFact}"
                      </p>
                    </div>
                    <div className="mt-4 text-xs text-[#A35D36] font-semibold flex items-center gap-1.5">
                      💪 Nutrition Science for Kids!
                    </div>
                  </div>

                  {/* Move Challenge Card */}
                  <div className={`p-5 rounded-3xl border-2 flex flex-col justify-between transition-all ${
                    moveChallengeDone 
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-800' 
                      : 'bg-[#FFFBEB] border-[#FFD93D] text-[#854d0e]'
                  }`}>
                    <div>
                      <div className="flex justify-between items-start mb-2">
                        <h5 className="text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5">
                          🏃‍♂️ MOVE CHALLENGE!
                        </h5>
                        {moveChallengeDone && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                            COMPLETED ⭐
                          </span>
                        )}
                      </div>
                      <p className="text-xs sm:text-sm font-bold leading-relaxed">
                        {recipe.moveChallenge}
                      </p>
                    </div>

                    <div className="mt-4 pt-2">
                      {moveChallengeDone ? (
                        <p className="text-xs font-black text-emerald-700 italic flex items-center gap-1">
                          🎉 Engines fired up & ready to digest!
                        </p>
                      ) : (
                        <button
                          id="btn-complete-challenge"
                          onClick={handleCompleteMoveChallenge}
                          className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs rounded-xl shadow-xs transition-transform hover:scale-102 flex items-center justify-center gap-1.5"
                        >
                          🦖 Done the Challenge!
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Move challenge confetti simulation banner */}
                {showMoveConfetti && (
                  <div className="p-3 bg-gradient-to-r from-amber-400 to-yellow-300 rounded-2xl text-[#7D4427] font-black text-xs text-center border-2 border-yellow-400 animate-bounce">
                    ✨ Sparkle Power Activators Online! You stomped like a real dinosaur! 🦖✨ Let's enjoy!
                  </div>
                )}

              </div>
            </div>

            {/* Bottom Navigation & Youtube assistant */}
            <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 mt-6 text-white shadow-xl flex flex-col lg:flex-row items-center justify-between gap-6">
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
                 <div className="bg-red-500 rounded-full p-3 shadow-lg shrink-0">
                   <PlayCircle className="w-8 h-8 text-white" />
                 </div>
                 <div className="text-center sm:text-left">
                    <h4 className="font-black text-lg text-white flex items-center justify-center sm:justify-start gap-2">Watch a Video Guide! 📺</h4>
                    <p className="text-slate-400 text-sm mt-1 mb-3">Check out this search to see parents making something similar.</p>
                    <div className="bg-slate-800 p-3 rounded-xl border border-slate-700 inline-flex flex-col sm:flex-row items-center gap-3 w-full">
                       <code className="text-yellow-400 font-mono font-bold text-xs select-all text-center sm:text-left break-all">"{recipe.tutorialQuery}"</code>
                       <a href={`https://www.youtube.com/results?search_query=${encodeURIComponent(recipe.tutorialQuery)}`} target="_blank" rel="noopener noreferrer" className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 text-xs font-bold rounded-lg transition-colors shrink-0 whitespace-nowrap">
                         Search YouTube
                       </a>
                    </div>
                 </div>
              </div>

              <button
                onClick={() => setRecipe(null)}
                className="w-full lg:w-auto px-8 py-4 bg-white hover:bg-slate-100 text-slate-900 font-black text-sm rounded-xl shadow-md transition-all shrink-0"
              >
                🌿 Return to Pantry
              </button>
            </div>

          </div>
        )}

        {/* Global Footer Details */}
        <footer className="mt-12 flex flex-col sm:flex-row items-center justify-between text-slate-400 px-4 py-6 border-t border-slate-200/60 text-center gap-2">
          <p className="text-[10px] sm:text-xs font-bold uppercase tracking-widest flex items-center gap-1.5">
            🍎 Based on the Harvard Kid’s Healthy Eating Plate Model
          </p>
          <p className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-slate-400">
            © 2026 Chef Nutri-Kid • Hand-prepared with Clinical Culinary Love
          </p>
        </footer>

      </div>
    </div>
  );
}
